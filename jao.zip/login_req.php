<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "logindb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$loginName = $_POST['txtusername'];
$loginPassword = $_POST['txtpassword'];

// Clear old scalar session variables if they exist
if (isset($_SESSION['login_attempts']) && !is_array($_SESSION['login_attempts'])) {
    unset($_SESSION['login_attempts']);
}

// Initialize array if it doesn't exist
if (!isset($_SESSION['login_attempts']) || !is_array($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = array();
}

// Reset attempts if no POST data (page refresh)
if (empty($_POST)) {
    $_SESSION['login_attempts'] = array();
} 

// Initialize attempts for this specific user if not set
if (!isset($_SESSION['login_attempts'][$loginName])) {
    $_SESSION['login_attempts'][$loginName] = 0;
}

// Check if account is already disabled
if ($_SESSION['login_attempts'][$loginName] >= 3) {
    echo "BANNED FOR LIFE!";
    $conn->close();
    exit();
}

$stmt = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
$stmt->bind_param("s", $loginName);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($db_username, $db_password);
    $stmt->fetch();

    // Validate the password no hashing yet (text to text comparison)
    if ($loginPassword === $db_password) {
        // Reset attempts on successful login
        $_SESSION['login_attempts'][$loginName] = 0;
        echo "Welcome " . htmlspecialchars($loginName);
    } else {
        $_SESSION['login_attempts'][$loginName]++;
        echo $_SESSION['login_attempts'][$loginName] > 3 ? "Account Disabled" : "Invalid Credentials";
    }
} else {
    $_SESSION['login_attempts'][$loginName]++;
    echo $_SESSION['login_attempts'][$loginName] > 3 ? "Account Disabled" : "Invalid Credentials";
}

$stmt->close();
$conn->close();
?>